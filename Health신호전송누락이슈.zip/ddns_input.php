<?
//  (��)HV
//  Caps STL DDNS Server ����
//  2017.04.10
//  �ۼ��� �ڿ���
//  Ver 2.0.0

extract($_GET);
require("./module/constant.php");
require("./module/db_mysql.php");
require("./module/db_mysql2.php");

//http://192.168.1.234/ddns_input.php?ddns_mac=001c843d5881&ddns_model=NVR-08M2S&ddns_Acc_no=1111&ddns_in_ip=192.168.0.6&ddns_hdd=2000&ddns_ch=1011001000000000&ddns_firm=2.0.7&ddns_dvr_date=00000000&ddns_dvr_time=000000&ddns_web_port=8049&ddns_net_port=3049

$MY_SQL = new MY_SQL();
$MY_SQL_2 = new MY_SQL_2();

$ddns_reg_date = date("Y-m-d");
//
$_time_ch = strlen($_time);
if($_time_ch == 5){
	$_time = '0'.$_time;
}
//
if($UID)
	$UID = trim($UID);
	
	// MySQL ���ν����� ������ 2017.04.10 - ���������Ӵ�, �̼�ȭ�����
	//$ddns_st_se_query = "CALL UPDATE_DDNS('$ddns_model', '$ip_addr', '$ddns_in_ip', '$ddns_hdd', '$ddns_ch', '$ddns_firm', '$ddns_dvr_date', '$ddns_dvr_time', '$ddns_web_port', '$ddns_net_port', '$_date', '$_time', '$UID', '$ddns_mac', '$ddns_reg_date')";
	//$ddns_st_se_resolut = $MY_SQL->sql_query($ddns_st_se_query);


// MySQL ���ν������� �ٽ� PHP������ ������ 2017.09.05 - �̼�ȣ�����

//������ ���Ӵ� ��û. ����߰��� �� ���з�ƾ ���� 2019 06 27
//������ ���Ӵ� ��û. ����߰��� �� ���з�ƾ ��� �� ��ȭƮ�� ���ּ� ���(���ּ� ���ڸ�: 002363) 2019 06 27

if($ddns_mac){
	
	if( (strtolower(substr(trim($ddns_mac), 0, 6)) == "90da6a") || (strtolower(substr(trim($ddns_mac), 0, 6)) == "001c84") || (strtolower(substr(trim($ddns_mac), 0, 6)) == "002363") ){
		//---------------------------------------------------------------------------------------------------------------------------------------- ù��° ���� ������Ʈ
		$ddns_mac = trim($ddns_mac);
		
		$ddns_st_se_query = "SELECT ddns_seq FROM ddns_st WHERE ddns_mac = '$ddns_mac'";
		$ddns_st_se_resolut = $MY_SQL->sql_query($ddns_st_se_query);
		$ddns_st_se_row = $MY_SQL->sql_fetch_object($ddns_st_se_resolut);	
		
		if($ddns_st_se_row){  // ddns_st Table���� �˻��� �Ǿ����� ������.
			$ddns_st_up_query = "UPDATE ddns_st SET ddns_model = '$ddns_model', ddns_out_ip = '$ip_addr', ddns_in_ip = '$ddns_in_ip', ddns_hdd = '$ddns_hdd', ddns_ch = '$ddns_ch', ddns_firm = '$ddns_firm', 
							ddns_dvr_date = '$ddns_dvr_date', ddns_dvr_time = '$ddns_dvr_time', ddns_web_port = '$ddns_web_port', ddns_net_port = '$ddns_net_port', ddns_server_date = '$_date', 
							ddns_server_time = '$_time', ddns_uid = '$UID', ddns_camerausage = '$CAMERAUSAGE'   
							WHERE ddns_mac = '$ddns_mac'";
							
			$ddns_st_up_resolut = $MY_SQL->sql_query($ddns_st_up_query);	
		}else {		
			$ddns_st_in_query = "INSERT INTO ddns_st (ddns_mac, ddns_uid, ddns_model, ddns_out_ip, ddns_in_ip, ddns_web_port, ddns_net_port, ddns_hdd, ddns_ch, ddns_firm, 
									ddns_dvr_date, ddns_dvr_time, ddns_server_date, ddns_server_time, ddns_reg_date, ddns_camerausage)
								VALUES('$ddns_mac', '$UID', '$ddns_model', '$ip_addr', '$ddns_in_ip', '$ddns_web_port', '$ddns_net_port', '$ddns_hdd', '$ddns_ch', '$ddns_firm', 
									'$ddns_dvr_date', '$ddns_dvr_time', '$_date', '$_time', '$ddns_reg_date', '$CAMERAUSAGE')";	
			
			$ddns_st_in_resolut = $MY_SQL->sql_query($ddns_st_in_query);
		}
		$close = $MY_SQL->sql_close($MY_SQL->connection_id);
		//---------------------------------------------------------------------------------------------------------------------------------------- ù��° ���� ������Ʈ
		//---------------------------------------------------------------------------------------------------------------------------------------- �ι�° ���� ������Ʈ	
		$ddns_st_se_query = "SELECT ddns_seq FROM ddns_st WHERE ddns_mac = '$ddns_mac'";
		$ddns_st_se_resolut = $MY_SQL_2->sql_query($ddns_st_se_query);	
		$ddns_st_se_row = $MY_SQL_2->sql_fetch_object($ddns_st_se_resolut);
		
		if($ddns_st_se_row){  // ddns_st Table���� �˻��� �Ǿ����� ������.
			$ddns_st_up_query = "UPDATE ddns_st SET ddns_model = '$ddns_model', ddns_out_ip = '$ip_addr', ddns_in_ip = '$ddns_in_ip', ddns_hdd = '$ddns_hdd', ddns_ch = '$ddns_ch', ddns_firm = '$ddns_firm', 
							ddns_dvr_date = '$ddns_dvr_date', ddns_dvr_time = '$ddns_dvr_time', ddns_web_port = '$ddns_web_port', ddns_net_port = '$ddns_net_port', ddns_server_date = '$_date', 
							ddns_server_time = '$_time', ddns_uid = '$UID' 
							WHERE ddns_mac = '$ddns_mac'";
			
			$ddns_st_up_resolut = $MY_SQL_2->sql_query($ddns_st_up_query);	
			//if(!$ddns_st_up_resolut){ $MY_SQL_2->sql_error($ddns_st_up_query); }
		}else {		
			$ddns_st_in_query = "INSERT INTO ddns_st (ddns_mac, ddns_uid, ddns_model, ddns_out_ip, ddns_in_ip, ddns_web_port, ddns_net_port, ddns_hdd, ddns_ch, ddns_firm, 
									ddns_dvr_date, ddns_dvr_time, ddns_server_date, ddns_server_time, ddns_reg_date)
								VALUES('$ddns_mac', '$UID', '$ddns_model', '$ip_addr', '$ddns_in_ip', '$ddns_web_port', '$ddns_net_port', '$ddns_hdd', '$ddns_ch', '$ddns_firm', 
									'$ddns_dvr_date', '$ddns_dvr_time', '$_date', '$_time', '$ddns_reg_date')";	
			
			$ddns_st_in_resolut = $MY_SQL_2->sql_query($ddns_st_in_query);
		}
		$close = $MY_SQL_2->sql_close($MY_SQL_2->connection_id);	
		//---------------------------------------------------------------------------------------------------------------------------------------- �ι�° ���� ������Ʈ
		echo "<!--[[DDNS_REG_OK & $ip_addr & ]]-->";
	}
}
?>


